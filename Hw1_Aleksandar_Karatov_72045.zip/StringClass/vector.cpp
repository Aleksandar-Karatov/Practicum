// 09_04_.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

template <typename T>
class myVector
{
public:
	myVector()
	{
		data = new T[capacity];
		size = 0;
		capacity = 8;
	}
	myVector(const myVector<T>& other);
	myVector(const T*);
	size_t getSize()const
	{
		return size;
	}
	size_t getCapacity()const
	{
		return capacity;
	}
	T* getData()const
	{
		return data;
	}
	myVector<T>& operator= (const myVector<T>& other);
	T& operator[] (const size_t index)const;
	void pushBack(const T& toAdd);
	~myVector()
	{
		delete[] data;
		data = nullptr;
	}

private:
	T* data;
	size_t size;
	size_t capacity;
	void copy(const myVector<T>& other)
	{
		if (this != &other)
		{
			size = other.size;
			capacity = other.capacity;
			data = new T[capacity];
			for (size_t i = 0; i < size; i++)
			{
				data[i] = other.data[i];
			}
		}
	}
	void resize()
	{
		capacity *= 2;
		T* buffer = new T[capacity];
		for (size_t i = 0; i < size; i++)
		{
			buffer[i] = data[i];
		}
		data = new T[capacity];
		for (size_t i = 0; i < size; i++)
		{
			 data[i] = buffer[i];
		}
		
	}
	void destroy()
	{
		delete[] data;
	}
};
template<typename T>
myVector<T>::myVector(const myVector<T>& other)
{
	copy(other);
}
template<typename T>
myVector<T>::myVector(const T* Data)
{
	size_t Size = 0;
	while (Data[Size] != NULL)
	{
		Size++;
	}
	size_t Capacity = 8;
	while (Capacity < Size)
	{
		Capacity *= 2;
	}
	size = Size;
	capacity = Capacity;
	data = new T[capacity];
	for (size_t i = 0; i < size; i++)
	{
		data[i] = Data[i];
	}
}
template<typename T>
myVector<T>& myVector<T> :: operator= (const myVector<T>& other)
{
	if (this != &other)
	{
		destroy();
		copy(other);
	}
	return *this;
}
template <typename T>
T& myVector<T>:: operator[] (const size_t index)const
{
	if (index > size)
	{
		exit(1);
	}
	return data[index];
}
template<typename T>
void myVector<T>::pushBack(const T& toAdd)
{
	if (size + 1 >= capacity)
	{
		resize();
	}
	data[size] = toAdd;
	size++;
}


int main()
{
	myVector<int> test1;
	std::cout << "Capacity:" << test1.getCapacity() << std::endl << "Size:" << test1.getSize() << std::endl;
	test1.pushBack(1);
	test1.pushBack(2);
	test1.pushBack(3);
	test1.pushBack(4);
	test1.pushBack(5);
	test1.pushBack(6);
	test1.pushBack(7);
	test1.pushBack(8);
	test1.pushBack(9);

	std::cout << "Capacity:" << test1.getCapacity() << std::endl << "Size:" << test1.getSize() << std::endl;
	myVector<int> test2 = test1;
	std::cout << "Capacity:" << test2.getCapacity() << std::endl << "Size:" << test2.getSize() << std::endl;
	myVector<int> test3 = myVector<int>(test2);
	std::cout << "Capacity:" << test3.getCapacity() << std::endl << "Size:" << test3.getSize() << std::endl;

}

